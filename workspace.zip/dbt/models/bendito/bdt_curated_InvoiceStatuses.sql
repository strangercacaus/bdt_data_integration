{{ config(
    materialized = 'table',
    unique_key = 'id',
    post_hook=[
        "GRANT SELECT ON {{ this }} TO bendito_metabase"
    ],
)}}
SELECT ("CONTENT"->>' Id')::integer AS Id,
("CONTENT"->>' CustomerId')::integer AS CustomerId,
("CONTENT"->>' InvoiceId')::text AS InvoiceId,
("CONTENT"->>' StepCode')::text AS StepCode,
("CONTENT"->>' StepDescription')::text AS StepDescription,
("CONTENT"->>' CreatedAt')::timestamp with time zone AS CreatedAt
FROM {{source('bendito','btx_raw_InvoiceStatuses')}}