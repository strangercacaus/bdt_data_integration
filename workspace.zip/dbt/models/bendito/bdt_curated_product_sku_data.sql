{{ config(
        materialized = 'table',
        unique_key = 'id',
        post_hook=[
            "ALTER TABLE {{ this }} ADD PRIMARY KEY (id)",
            "GRANT SELECT ON {{ this }} TO bendito_metabase",

        ],
    )}}
SELECT ("CONTENT"->>'id')::integer AS id,
("CONTENT"->>'id_sku')::integer AS id_sku,
("CONTENT"->>'description')::character varying AS description,
("CONTENT"->>'status')::integer AS status,
("CONTENT"->>'suplier_code')::character varying AS suplier_code,
("CONTENT"->>'customer_code')::character varying AS customer_code,
("CONTENT"->>'images')::text[] AS images,
("CONTENT"->>'integration_code')::character varying AS integration_code,
("CONTENT"->>'additional_information')::text AS additional_information,
("CONTENT"->>'b2b_sale')::boolean AS b2b_sale,
("CONTENT"->>'ean')::character varying AS ean,
("CONTENT"->>'stock')::numeric AS stock,
("CONTENT"->>'stock_reserved')::numeric AS stock_reserved,
("CONTENT"->>'id_user_creation')::integer AS id_user_creation,
("CONTENT"->>'time_creation')::timestamp without time zone AS time_creation,
("CONTENT"->>'id_user_modification')::integer AS id_user_modification,
("CONTENT"->>'time_modification')::timestamp without time zone AS time_modification,
("CONTENT"->>'imported')::boolean AS imported,
("CONTENT"->>'resale')::boolean AS resale,
("CONTENT"->>'price')::numeric AS price,
("CONTENT"->>'stock_restrition')::boolean AS stock_restrition,
("CONTENT"->>'numero_fci')::character varying AS numero_fci
FROM {{source('bendito','bdt_raw_product_sku_data')}}