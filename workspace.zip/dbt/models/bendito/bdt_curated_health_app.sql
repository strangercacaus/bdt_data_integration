{{ config(
    materialized = 'table',
    unique_key = 'id',
    post_hook=[
        "GRANT SELECT ON {{ this }} TO bendito_metabase"
    ],
)}}
SELECT ("CONTENT"->>' app')::character varying AS app,
("CONTENT"->>' version')::character varying AS version,
("CONTENT"->>' up')::boolean AS up,
("CONTENT"->>' updated_at')::timestamp without time zone AS updated_at
FROM {{source('bendito','btx_raw_health_app')}}