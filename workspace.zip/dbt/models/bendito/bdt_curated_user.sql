{{ config(
        materialized = 'table',
        unique_key = 'id',
        post_hook=[
            "ALTER TABLE {{ this }} ADD PRIMARY KEY (id)",
            "GRANT SELECT ON {{ this }} TO bendito_metabase",

        ],
    )}}
SELECT ("CONTENT"->>'id')::integer AS id,
("CONTENT"->>'username')::character varying AS username,
("CONTENT"->>'password')::character varying AS password,
("CONTENT"->>'status')::integer AS status,
("CONTENT"->>'type')::integer AS type,
("CONTENT"->>'first_name')::character varying AS first_name,
("CONTENT"->>'last_name')::character varying AS last_name,
("CONTENT"->>'nick_name')::character varying AS nick_name,
("CONTENT"->>'birthday')::date AS birthday,
("CONTENT"->>'gender')::integer AS gender,
("CONTENT"->>'phone_prefix')::integer AS phone_prefix,
("CONTENT"->>'phone_number')::integer AS phone_number,
("CONTENT"->>'cellphone_prefix')::integer AS cellphone_prefix,
("CONTENT"->>'cellphone_number')::integer AS cellphone_number,
("CONTENT"->>'validated')::boolean AS validated,
("CONTENT"->>'last_access')::timestamp without time zone AS last_access,
("CONTENT"->>'time_modification')::timestamp without time zone AS time_modification,
("CONTENT"->>'id_user_creation')::integer AS id_user_creation,
("CONTENT"->>'time_creation')::timestamp without time zone AS time_creation,
("CONTENT"->>'id_user_modification')::integer AS id_user_modification,
("CONTENT"->>'image')::character varying AS image,
("CONTENT"->>'integration_code')::character varying AS integration_code,
("CONTENT"->>'user_customized_id')::text AS user_customized_id,
("CONTENT"->>'is_admin')::boolean AS is_admin
FROM {{source('bendito','bdt_raw_user')}}