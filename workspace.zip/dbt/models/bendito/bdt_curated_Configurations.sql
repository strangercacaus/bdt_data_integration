{{ config(
    materialized = 'table',
    unique_key = 'id',
    post_hook=[
        "GRANT SELECT ON {{ this }} TO bendito_metabase"
    ],
)}}
SELECT ("CONTENT"->>' Id')::integer AS Id,
("CONTENT"->>' CustomerId')::integer AS CustomerId,
("CONTENT"->>' Key')::text AS Key,
("CONTENT"->>' Secret')::text AS Secret,
("CONTENT"->>' CurrentAccountDefault')::text AS CurrentAccountDefault,
("CONTENT"->>' SalesPersonDefault')::text AS SalesPersonDefault,
("CONTENT"->>' ImportOnlySellProducts')::boolean AS ImportOnlySellProducts,
("CONTENT"->>' ImportOnlyActiveProducts')::boolean AS ImportOnlyActiveProducts,
("CONTENT"->>' ImportOnlyActiveClients')::boolean AS ImportOnlyActiveClients,
("CONTENT"->>' IgnoreStockAndWarehouses')::boolean AS IgnoreStockAndWarehouses,
("CONTENT"->>' ImportPaymentMethod')::boolean AS ImportPaymentMethod,
("CONTENT"->>' ImportPreferredSalesPerson')::boolean AS ImportPreferredSalesPerson,
("CONTENT"->>' FinalCustomer')::boolean AS FinalCustomer,
("CONTENT"->>' SendDiscount')::boolean AS SendDiscount,
("CONTENT"->>' UseSku')::boolean AS UseSku,
("CONTENT"->>' Categories')::ARRAY AS Categories,
("CONTENT"->>' Warehouses')::ARRAY AS Warehouses,
("CONTENT"->>' Tags')::ARRAY AS Tags,
("CONTENT"->>' ImportOnlyClientType')::integer AS ImportOnlyClientType,
("CONTENT"->>' CreatedAt')::timestamp with time zone AS CreatedAt,
("CONTENT"->>' Type')::integer AS Type,
("CONTENT"->>' Token')::text AS Token
FROM {{source('bendito','btx_raw_Configurations')}}