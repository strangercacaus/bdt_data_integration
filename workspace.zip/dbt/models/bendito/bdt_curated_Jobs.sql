{{ config(
    materialized = 'table',
    unique_key = 'id',
    post_hook=[
        "GRANT SELECT ON {{ this }} TO bendito_metabase"
    ],
)}}
SELECT ("CONTENT"->>' Id')::integer AS Id,
("CONTENT"->>' Total')::integer AS Total,
("CONTENT"->>' Executed')::integer AS Executed,
("CONTENT"->>' CustomerId')::integer AS CustomerId,
("CONTENT"->>' CustomerName')::text AS CustomerName,
("CONTENT"->>' Message')::text AS Message,
("CONTENT"->>' Data')::json AS Data,
("CONTENT"->>' Type')::integer AS Type,
("CONTENT"->>' Status')::integer AS Status,
("CONTENT"->>' Entity')::integer AS Entity,
("CONTENT"->>' CreatedAt')::timestamp with time zone AS CreatedAt
FROM {{source('bendito','btx_raw_Jobs')}}