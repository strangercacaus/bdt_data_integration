{{ config(
        materialized = 'table',
        unique_key = 'id',
        post_hook=[
            "ALTER TABLE {{ this }} ADD PRIMARY KEY (id)",
            "GRANT SELECT ON {{ this }} TO bendito_metabase",

        ],
    )}}
SELECT ("CONTENT"->>'id_customer')::integer AS id_customer,
("CONTENT"->>'id')::integer AS id,
("CONTENT"->>'description')::character varying AS description,
("CONTENT"->>'id_user_creation')::integer AS id_user_creation,
("CONTENT"->>'time_creation')::timestamp without time zone AS time_creation,
("CONTENT"->>'id_user_modification')::integer AS id_user_modification,
("CONTENT"->>'time_modification')::timestamp without time zone AS time_modification,
("CONTENT"->>'id_family')::integer AS id_family,
("CONTENT"->>'customer_code')::character varying AS customer_code,
("CONTENT"->>'integration_code')::character varying AS integration_code,
("CONTENT"->>'b2b_sale')::boolean AS b2b_sale,
("CONTENT"->>'detailed_description')::character varying AS detailed_description,
("CONTENT"->>'image')::text AS image,
("CONTENT"->>'description_2')::character varying AS description_2,
("CONTENT"->>'detailed_description_2')::character varying AS detailed_description_2,
("CONTENT"->>'description_3')::character varying AS description_3,
("CONTENT"->>'detailed_description_3')::character varying AS detailed_description_3,
("CONTENT"->>'app_sale')::boolean AS app_sale
FROM {{source('bendito','bdt_raw_family')}}