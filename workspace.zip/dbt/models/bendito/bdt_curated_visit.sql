{{ config(
    materialized = 'table',
    unique_key = 'id',
    post_hook=[
        "GRANT SELECT ON {{ this }} TO bendito_metabase"
    ],
)}}
SELECT ("CONTENT"->>' id')::integer AS id,
("CONTENT"->>' status')::integer AS status,
("CONTENT"->>' result')::integer AS result,
("CONTENT"->>' id_seller')::integer AS id_seller,
("CONTENT"->>' id_customer')::integer AS id_customer,
("CONTENT"->>' id_client')::integer AS id_client,
("CONTENT"->>' id_route_execution')::integer AS id_route_execution,
("CONTENT"->>' id_lostreason')::integer AS id_lostreason,
("CONTENT"->>' check_in_at')::timestamp without time zone AS check_in_at,
("CONTENT"->>' check_in_coord')::character varying AS check_in_coord,
("CONTENT"->>' check_in_image')::character varying AS check_in_image,
("CONTENT"->>' check_out_at')::timestamp without time zone AS check_out_at,
("CONTENT"->>' check_out_coord')::character varying AS check_out_coord,
("CONTENT"->>' check_out_image')::character varying AS check_out_image,
("CONTENT"->>' notes')::text AS notes,
("CONTENT"->>' id_user_creation')::integer AS id_user_creation,
("CONTENT"->>' time_creation')::timestamp without time zone AS time_creation,
("CONTENT"->>' id_user_modification')::integer AS id_user_modification,
("CONTENT"->>' time_modification')::timestamp without time zone AS time_modification
FROM {{source('bendito','btx_raw_visit')}}