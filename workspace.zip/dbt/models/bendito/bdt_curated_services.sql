{{ config(
    materialized = 'table',
    unique_key = 'id',
    post_hook=[
        "GRANT SELECT ON {{ this }} TO bendito_metabase"
    ],
)}}
SELECT ("CONTENT"->>' id')::integer AS id,
("CONTENT"->>' code')::character varying AS code,
("CONTENT"->>' description')::character varying AS description
FROM {{source('bendito','btx_raw_services')}}