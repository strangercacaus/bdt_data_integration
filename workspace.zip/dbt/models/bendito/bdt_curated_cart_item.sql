{{ config(
    materialized = 'table',
    unique_key = 'id',
    post_hook=[
        "GRANT SELECT ON {{ this }} TO bendito_metabase"
    ],
)}}
SELECT ("CONTENT"->>' id')::integer AS id,
("CONTENT"->>' cart')::integer AS cart,
("CONTENT"->>' item')::character varying AS item,
("CONTENT"->>' product')::integer AS product,
("CONTENT"->>' quantity')::numeric AS quantity,
("CONTENT"->>' value')::numeric AS value,
("CONTENT"->>' tax')::numeric AS tax,
("CONTENT"->>' freight')::numeric AS freight,
("CONTENT"->>' discount')::numeric AS discount,
("CONTENT"->>' total_value')::numeric AS total_value,
("CONTENT"->>' id_user_creation')::integer AS id_user_creation,
("CONTENT"->>' time_creation')::timestamp without time zone AS time_creation,
("CONTENT"->>' id_user_modification')::integer AS id_user_modification,
("CONTENT"->>' time_modification')::timestamp without time zone AS time_modification,
("CONTENT"->>' comments')::text AS comments,
("CONTENT"->>' productskudataid')::integer AS productskudataid,
("CONTENT"->>' addition')::numeric AS addition
FROM {{source('bendito','btx_raw_cart_item')}}