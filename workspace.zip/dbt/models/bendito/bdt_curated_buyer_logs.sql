{{ config(
    materialized = 'table',
    unique_key = 'id',
    post_hook=[
        "GRANT SELECT ON {{ this }} TO bendito_metabase"
    ],
)}}
SELECT ("CONTENT"->>' id')::integer AS id,
("CONTENT"->>' timestamp')::timestamp without time zone AS timestamp,
("CONTENT"->>' buyer_id')::integer AS buyer_id,
("CONTENT"->>' customer_id')::integer AS customer_id,
("CONTENT"->>' type')::integer AS type
FROM {{source('bendito','btx_raw_buyer_logs')}}