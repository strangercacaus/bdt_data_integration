{{ config(
        materialized = 'view',
        unique_key = 'id',
        post_hook=[
            "GRANT SELECT ON {{ this }} TO bendito_metabase"
        ],
    )}}
SELECT ("CONTENT"->>'id')::integer AS id,
("CONTENT"->>'type')::integer AS type,
("CONTENT"->>'registration_code')::character varying AS registration_code,
("CONTENT"->>'company_name')::character varying AS company_name,
("CONTENT"->>'social_name')::character varying AS social_name,
("CONTENT"->>'registration_state')::character varying AS registration_state,
("CONTENT"->>'registration_city')::character varying AS registration_city,
("CONTENT"->>'taxpayer')::integer AS taxpayer,
("CONTENT"->>'taxing')::integer AS taxing,
("CONTENT"->>'final_costumer')::boolean AS final_costumer,
("CONTENT"->>'registration_state_required')::boolean AS registration_state_required,
("CONTENT"->>'id_user_creation')::integer AS id_user_creation,
("CONTENT"->>'time_creation')::timestamp without time zone AS time_creation,
("CONTENT"->>'id_user_modification')::integer AS id_user_modification,
("CONTENT"->>'time_modification')::timestamp without time zone AS time_modification,
("CONTENT"->>'image')::character varying AS image,
("CONTENT"->>'business_situation')::integer AS business_situation,
("CONTENT"->>'payment_method')::integer AS payment_method,
("CONTENT"->>'preferred_salesperson')::bigint AS preferred_salesperson,
("CONTENT"->>'tax_situation')::integer AS tax_situation
FROM {{source('bendito','bdt_raw_person')}}