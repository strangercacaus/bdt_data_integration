{{ config(
    materialized = 'table',
    unique_key = 'id',
    post_hook=[
        "GRANT SELECT ON {{ this }} TO bendito_metabase"
    ],
)}}
SELECT ("CONTENT"->>' id')::integer AS id,
("CONTENT"->>' name')::character varying AS name,
("CONTENT"->>' entity')::integer AS entity,
("CONTENT"->>' order')::integer AS order,
("CONTENT"->>' customer_id')::integer AS customer_id
FROM {{source('bendito','btx_raw_custom_group')}}